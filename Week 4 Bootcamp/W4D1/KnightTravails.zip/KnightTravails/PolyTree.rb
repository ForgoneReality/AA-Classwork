class PolyTreeNode
    attr_accessor :parent, :value
    def initialize(value, parent)
        @parent = parent
        @value = value 
    end
end

